This is a handwritten set of numbers and letter for generating the Captcha images. Feel free to use them or to generate your own.

Copy this images to your Authen/Captcha/images directory. Depending on your local Perl set-up this directory could be located like here:

/usr/local/share/perl/5.8.8/Authen/Captcha/images
